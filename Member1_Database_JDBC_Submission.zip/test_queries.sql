USE lost_found_db;

-- 1. Users
SELECT user_id,full_name,email,role FROM users ORDER BY user_id;

-- 2. Items and reporter names
SELECT i.item_id,i.title,i.category,i.item_status,i.location,u.full_name AS reported_by
FROM items i JOIN users u ON u.user_id=i.reported_by ORDER BY i.item_id;

-- 3. Found items
SELECT item_id,title,location,item_date FROM items
WHERE item_status='FOUND' ORDER BY item_date DESC;

-- 4. Claims with item and claimant
SELECT c.claim_id,i.title,u.full_name AS claimant,c.claim_status,c.claimed_at
FROM claims c JOIN items i ON i.item_id=c.item_id
JOIN users u ON u.user_id=c.claimant_id ORDER BY c.claimed_at DESC;

-- 5. Counts by status
SELECT item_status,COUNT(*) AS total FROM items GROUP BY item_status;

-- 6. Expected result: 0
SELECT COUNT(*) AS items_without_reporter FROM items i
LEFT JOIN users u ON u.user_id=i.reported_by WHERE u.user_id IS NULL;

-- 7. Expected result: no rows
SELECT c.claim_id FROM claims c
LEFT JOIN items i ON i.item_id=c.item_id
LEFT JOIN users u ON u.user_id=c.claimant_id
WHERE i.item_id IS NULL OR u.user_id IS NULL;
