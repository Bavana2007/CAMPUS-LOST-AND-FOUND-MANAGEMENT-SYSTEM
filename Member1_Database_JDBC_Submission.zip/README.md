# Member 1 — Database and JDBC

**Assumed project:** Lost and Found Management System  
**Database:** MySQL 8.0+  
**Java:** Java 8+ for the supplied source  
**Driver:** MySQL Connector/J

## Files
- `database.sql`: database, three tables, constraints, sample records, quick checks.
- `src/DBConnection.java`: reusable JDBC connection helper and connection test.
- `src/DatabaseTest.java`: JDBC query test.
- `test_queries.sql`: SQL verification queries.

## Database design
- `users`: user profile, unique email, role.
- `items`: item reports; `reported_by` references `users.user_id`.
- `claims`: claims; foreign keys reference the item and claimant.
- InnoDB enforces foreign keys. `ON DELETE RESTRICT` prevents deleting referenced records.
- One user can submit at most one claim per item (`UNIQUE(item_id, claimant_id)`).

The sample `password_hash` values are placeholders only. A real application must store securely generated password hashes, never plaintext passwords.

## Run the SQL
1. Open MySQL Workbench and connect to your local server.
2. Open `database.sql` and execute the entire script.
3. Confirm `lost_found_db` contains `users`, `items`, and `claims`.
4. Run `test_queries.sql`.

**Warning:** `database.sql` drops and recreates these tables. Use it only for a fresh/demo database, not for data you need to preserve.

## Configure and test JDBC
1. Download MySQL Connector/J from https://dev.mysql.com/downloads/connector/j/
2. Open `src/DBConnection.java` and replace `CHANGE_ME` with your local MySQL password. Update `DB_USER` if needed.
3. Add the Connector/J JAR to your IDE project's libraries/classpath.
4. Make sure MySQL is running and the SQL script has run.
5. Run `DBConnection.main()`. Expected success message: `SUCCESS: Connected to lost_found_db.`
6. Run `DatabaseTest.main()`. It should print three sample items.

Do not share real database passwords in team chat or commit them to a public repository.

## Troubleshooting
- `Access denied`: check username/password and permissions.
- `Unknown database`: run `database.sql`.
- `Communications link failure`: start MySQL and confirm port 3306.
- `No suitable driver`: add Connector/J to the runtime classpath.
- If SSL/authentication settings cause errors, follow your institution's MySQL configuration and security requirements.

## Evidence to add before submission
Take your own screenshots of:
1. The three tables in MySQL Workbench.
2. Query results for `SELECT * FROM users;`, `SELECT * FROM items;`, and `SELECT * FROM claims;`.
3. Successful `DBConnection` output.
4. Successful `DatabaseTest` output.

The source files are prepared, but the JDBC connection is not verified until you run it with your actual MySQL service, driver, and credentials.
