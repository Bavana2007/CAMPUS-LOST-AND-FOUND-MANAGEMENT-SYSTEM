-- Member 1: Database and JDBC | Lost and Found Management System
CREATE DATABASE IF NOT EXISTS lost_found_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lost_found_db;

-- Development/demo script: drops existing tables and recreates them.
DROP TABLE IF EXISTS claims;
DROP TABLE IF EXISTS items;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20),
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('USER','ADMIN') NOT NULL DEFAULT 'USER',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE items (
  item_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  description TEXT,
  category VARCHAR(60) NOT NULL,
  item_status ENUM('LOST','FOUND','CLAIMED') NOT NULL,
  location VARCHAR(180) NOT NULL,
  item_date DATE NOT NULL,
  reported_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_items_status (item_status),
  INDEX idx_items_category (category),
  CONSTRAINT fk_items_reported_by FOREIGN KEY (reported_by)
    REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE claims (
  claim_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  item_id INT UNSIGNED NOT NULL,
  claimant_id INT UNSIGNED NOT NULL,
  claim_message VARCHAR(500) NOT NULL,
  claim_status ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  claimed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at TIMESTAMP NULL DEFAULT NULL,
  INDEX idx_claims_item (item_id),
  INDEX idx_claims_claimant (claimant_id),
  INDEX idx_claims_status (claim_status),
  CONSTRAINT fk_claims_item FOREIGN KEY (item_id)
    REFERENCES items(item_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_claims_user FOREIGN KEY (claimant_id)
    REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT uq_claims_item_user UNIQUE (item_id, claimant_id)
) ENGINE=InnoDB;

-- Demo-only placeholder hashes; replace with secure hashes in the real application.
INSERT INTO users (full_name,email,phone,password_hash,role) VALUES
('Asha Kumar','asha@example.com','9000000001','DEMO_HASH_REPLACE_WITH_SECURE_HASH','USER'),
('Rahul Sharma','rahul@example.com','9000000002','DEMO_HASH_REPLACE_WITH_SECURE_HASH','USER'),
('System Admin','admin@example.com','9000000003','DEMO_HASH_REPLACE_WITH_SECURE_HASH','ADMIN');

INSERT INTO items (title,description,category,item_status,location,item_date,reported_by) VALUES
('Black backpack','Black backpack with a blue keychain.','Bags','LOST','Library, Block A','2026-10-14',1),
('Student ID card','ID card found near the cafeteria.','ID Cards','FOUND','College cafeteria','2026-10-15',2),
('Silver water bottle','Metal bottle with a small sticker.','Accessories','FOUND','Computer lab, Room 204','2026-10-15',2);

INSERT INTO claims (item_id,claimant_id,claim_message,claim_status) VALUES
(2,1,'The details on the ID card match my information.','PENDING');

-- Quick verification
SELECT user_id,full_name,email,role FROM users;
SELECT item_id,title,item_status,location FROM items;
SELECT claim_id,item_id,claimant_id,claim_status FROM claims;
