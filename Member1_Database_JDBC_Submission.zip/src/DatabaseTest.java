import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** JDBC smoke test: lists items and the users who reported them. */
public class DatabaseTest {
    public static void main(String[] args) {
        String sql = "SELECT i.item_id, i.title, i.item_status, u.full_name AS reporter " +
                     "FROM items i JOIN users u ON u.user_id = i.reported_by " +
                     "ORDER BY i.item_id";
        try (Connection connection = DBConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {
            System.out.println("JDBC query succeeded. Sample items:");
            while (rs.next()) {
                System.out.printf("%d | %s | %s | reported by %s%n",
                    rs.getInt("item_id"), rs.getString("title"),
                    rs.getString("item_status"), rs.getString("reporter"));
            }
        } catch (SQLException e) {
            System.err.println("Database test failed: " + e.getMessage());
        }
    }
}
