import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Shared JDBC connection utility for lost_found_db. */
public final class DBConnection {
    private static final String URL =
        "jdbc:mysql://localhost:3306/lost_found_db?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "CHANGE_ME";

    private DBConnection() {}

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, DB_USER, DB_PASSWORD);
    }

    public static void main(String[] args) {
        try (Connection connection = getConnection()) {
            System.out.println("SUCCESS: Connected to lost_found_db.");
            System.out.println("Database: " + connection.getCatalog());
        } catch (SQLException e) {
            System.err.println("ERROR: Could not connect to MySQL.");
            System.err.println("Check MySQL service, database.sql, credentials, and Connector/J classpath.");
            System.err.println("Details: " + e.getMessage());
        }
    }
}
